module.exports = {
    name: 'stopwish',
    short_name: 'sw',
    description: 'Remove a game from your wish list.',
    arguments: '<game>',
    showOnHelp: false,
    async execute(client, message, args, Discord, db) {

    }
}