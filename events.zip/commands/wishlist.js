module.exports = {
    name: 'wishlist',
    short_name: 'wl',
    description: 'Displays your wish list',
    arguments: '',
    showOnHelp: false,
    async execute(client, message, args, Discord, db) {

    }
}