module.exports = {
    name: 'wish',
    short_name: 'w',
    description: 'Add a game to your wish list. I will notify you when the game drops under a specified price.',
    arguments: '<game> <price>',
    showOnHelp: false,
    async execute(client, message, args, Discord, db) {

    }
}